from django.contrib import admin
from myfirstapp.models import Topic, WebInfo
# Register your models here.

admin.site.register(Topic)
admin.site.register(WebInfo)
