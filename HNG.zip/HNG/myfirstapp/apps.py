from django.apps import AppConfig


class MyfirstappConfig(AppConfig):
    name = 'myfirstapp'
